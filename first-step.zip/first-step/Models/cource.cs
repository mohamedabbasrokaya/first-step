﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace first_step.Models
{
    public class cource
    {
        public int id { get; set; }
        public string name { get; set; }
        public int categoryid { get; set; }
        
    }

}

